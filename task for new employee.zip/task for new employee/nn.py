import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

from keras import Sequential
from keras.layers import Dense

from pre import preprocess 

#dataset = pd.read_csv('pima_indian_data.csv')
path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"
X, y, data_test = preprocess(path)
#print(dataset.head(2))
#dataset.describe(include='all')
#X= dataset.iloc[:,0:8]
#y= dataset.iloc[:,8]
print(X.head(2))


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

classifier = Sequential()
#First Hidden Layer
classifier.add(Dense(4, activation='relu', kernel_initializer='random_normal', input_dim=136))
#Second  Hidden Layer
classifier.add(Dense(4, activation='relu', kernel_initializer='random_normal'))
#Output Layer
classifier.add(Dense(1, activation='sigmoid', kernel_initializer='random_normal'))
#Compiling the neural network
classifier.compile(optimizer ='adam',loss='binary_crossentropy', metrics =['accuracy'])
#Fitting the data to the training dataset
classifier.fit(X_train,y_train, batch_size=10, epochs=5)

eval_model=classifier.evaluate(X_train, y_train)
print(eval_model)

y_pred=classifier.predict(X_test)
y_pred =(y_pred>0.5)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print(cm)
target_pred = classifier.predict(data_test)
target_pred = pd.DataFrame(target_pred)
target_pred.to_csv('predictionsNN.csv')
#first epoch  36s 445us/step - loss: 0.2762 - acc: 0.8836