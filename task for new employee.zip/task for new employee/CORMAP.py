import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"

train = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251', index_col=0)
#test_real = pd.read_csv(path + "test.csv", sep = ';', encoding = 'cp1251', index_col=0)

#subset_features = ['BDD_NAME', 'LIFETIME',	'TARIFF_DESC', 'BILL_SHOCK', 'INACTIVE_DAYS', 'REVENUE', 'ARPU', 'SILENTDAYS', 'ALL_SEC', 'TRAFFIC_MB', 'RECHARGE_CNT', 'CHURN']
subset_features = ['BDD_NAME', 'LIFETIME',	'TARIFF_DESC', 'BILL_SHOCK', 'REVENUE', 'ARPU', 'SILENTDAYS', 'TRAFFIC_MB', 'RECHARGE_CNT', 'CHURN']
data = train[subset_features]
corr = data.corr()
fig = plt.figure()
ax = fig.add_subplot(111)
cax = ax.matshow(corr,cmap='coolwarm', vmin=-1, vmax=1)
fig.colorbar(cax)
#ticks = np.arange(0,len(data.columns),1)
#ax.set_xticks(ticks)
#plt.xticks(rotation=90)
#ax.set_yticks(ticks)
ax.set_xticklabels(data.columns)
ax.set_yticklabels(data.columns)
plt.show()
plt.savefig('plots/cormap1.png')