import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import seaborn as sns

#path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"
def plot_data(path):
	train = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251', index_col=0)
	#test_real = pd.read_csv(path + "test.csv", sep = ';', encoding = 'cp1251', index_col=0)

	subset_features = ['BDD_NAME', 'LIFETIME',	'TARIFF_DESC', 'BILL_SHOCK', 'INACTIVE_DAYS', 'REVENUE', 'ARPU', 'SILENTDAYS', 'ALL_SEC', 'TRAFFIC_MB', 'RECHARGE_CNT']
	df = train[subset_features]
	rs = round(df.describe(),2)
	#print(df.head(n=2), rs)
	fig2 = plt.figure(2)
	hist = df.hist(bins=5, color='steelblue', edgecolor='black', linewidth=1, xlabelsize=8, ylabelsize=8, figsize=(10,9), ec='k', grid=False, density=True)    
	plt.tight_layout()   
	#plt.show()
	fig2.savefig('plots/hist.png')


	# set the background colour of the plot to white
	sns.set(style="whitegrid", color_codes=True)
	# setting the plot size for all plots
	sns.set(rc={'figure.figsize':(16,12), "font.size":8, "axes.labelsize":5, "axes.titlesize":8})
	# Remove the top and down margin
	sns.despine(offset=10, trim=True)
	# create a countplot
	cols = ["BDD_NAME", "TARIFF_DESC"]
	for i in range(2):
		plt.figure(i)
		fig_plot = sns.countplot(x =train[cols[i]],data=train,hue = 'CHURN')
		fig = fig_plot.get_figure()
		#plt.show()
		fig.savefig('plots/'+cols[i]+'.png')
	print("Some data features are plotted")
#plot_data(path)