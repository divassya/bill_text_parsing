# Compare Algorithms
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
import warnings
# load dataset
path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"
train  = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251')
le = preprocessing.LabelEncoder()
for str in ['BDD_NAME', 'TARIFF_DESC']:
	train[str] = le.fit_transform(train[str])
imp = SimpleImputer(missing_values=np.nan, strategy='mean')
train = pd.DataFrame(imp.fit_transform(train)) 
print("after imputing")
cols = [col for col in train.columns if col not in ['SUBSCRIBER_ID','CHURN']]
data = train[cols]
target = train.iloc[:,-1]
warnings.simplefilter(action="ignore", category=UserWarning)
# prepare configuration for cross validation test harness
seed = 7
# prepare models
models = []
models.append(('LR', LogisticRegression(solver="lbfgs", multi_class="auto")))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('NB', GaussianNB()))
#models.append(('DT', DecisionTreeClassifier()))
#models.append(('RF', RandomForestClassifier(n_estimators=100)))
# evaluate each model in turn
train_results = []
test_results = []
names = []
scoring = 'accuracy'
for name, model in models:
	kfold = model_selection.KFold(n_splits=10, random_state=seed, shuffle=True)
	cv_results = model_selection.cross_validate(model, data, target, cv=kfold, scoring=scoring, return_train_score=True)
	sorted(cv_results.keys())
	#cv_results = model_selection.cross_val_score(model, data, target, cv=kfold, scoring=scoring)
	train_results.append(cv_results['train_score'])
	test_results.append(cv_results['test_score'])
	names.append(name)
	msg = "%s: Train:%f (%f)" % (name, cv_results['train_score'].mean(), cv_results['train_score'].std())
	msg2 = "%s: Test:%f (%f)" % (name, cv_results['test_score'].mean(), cv_results['test_score'].std())

	print(msg, msg2)
# boxplot algorithm comparison
fig = plt.figure()
fig.suptitle('Algorithm Comparison')
ax = fig.add_subplot(111)
plt.boxplot(train_results)
plt.boxplot(test_results)
ax.set_xticklabels(names)
plt.show()
def plot_comparison(res, names):
	for i in range(2):
		fig =plt.figure(i)
		fig.suptitle('Algorithm Comparison'+str(i))
		ax = fig.add_subplot(111)
		plt.boxplot(res[i])
		ax.set_xticklabels(names)
		#plt.show()
		fig.savefig('plots/Alg_comp'+str(i)+'.png')
plot_comparison(res, names)