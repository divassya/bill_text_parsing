# import modules
import pandas as pd
import numpy as np
from sklearn.preprocessing  import  LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.linear_model import SGDClassifier

#store the path in a variable
path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"

#read in the data 
train  = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251')
test_real = pd.read_csv(path + "test.csv", sep = ';', encoding = 'cp1251')

# create the Labelencoder object
#le = preprocessing.LabelEncoder()

#drop_enc = OneHotEncoder(drop='first')


#imput nan values
#print(train.isnull().sum(), test_real.isnull().sum())
imp = SimpleImputer(missing_values=np.nan, strategy='mean')
#train = pd.DataFrame(imp.fit_transform(train)) 
train = imp.fit_transform(train) 
#test_real = imp.fit_transform(test_real)


for str in ['BDD_NAME', 'TARIFF_DESC']:
	train[str] = le.fit_transform(train[str])
	test_real[str] = le.fit_transform(test_real[str])
enc = OneHotEncoder(categorical_features =  ['BDD_NAME', 'TARIFF_DESC'], drop='first')
train = enc.fit_transform(train).toarray()
test_real = enc.fit_transform(train).toarray()
	
print(train.head(n=2))
print(test_real.head(n=2))
#print("SUBSCRIBER_ID : ",len(train['SUBSCRIBER_ID'].unique())) #=114480, each id is unique
# select columns other than 'SUBSCRIBER_ID' and 'CHURN' 
cols = [col for col in train.columns if col not in ['SUBSCRIBER_ID','CHURN']]
cols_test= [col for col in test_real.columns if col not in ['SUBSCRIBER_ID','CHURN']]
# dropping the  'SUBSCRIBER_ID' and 'CHURN'columns
std = preprocessing.StandardScaler()
data = std.fit_transform(train[cols])
data_test_real = std.fit(test_real[cols_test])
print(train.head(n=2))
print(test_real.head(n=2))
#assigning the CHURN column as target
target = train.iloc[:,-1]
#split data set into train and test sets
data_train, data_test, target_train, target_test = train_test_split(data,target, test_size = 0.30, random_state = 10)
#create an object of the type GaussianNB
gnb = GaussianNB()
#train the algorithm on training data and predict using the testing data
pred = gnb.fit(data_train, target_train).predict(data_test)
#print the accuracy score of the model
print("Naive-Bayes accuracy : ",accuracy_score(target_test, pred, normalize = True))
