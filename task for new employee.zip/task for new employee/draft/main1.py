# import modules
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.linear_model import SGDClassifier

#import seaborn as sns
#import matplotlib.pyplot as plt

#store the path in a variable
path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"

#read in the data 
train  = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251')

'''
#test = pd.read_csv(path + "test.csv", sep = ';', encoding = 'cp1251')
#print(train.shape)
#print(train.head(n = 2))
#print(train.tail(n = 2))
#print(train.select_dtypes(include = 'object'))


# set the background colour of the plot to white
sns.set(style="whitegrid", color_codes=True)
# setting the plot size for all plots
#for countplot 11.7,8.27
sns.set(rc={'figure.figsize':(16.7,13.27)})
# create a countplot
#sns.countplot(x ="BDD_NAME",data=train,hue = 'CHURN')
#sns.countplot(x ="TARIFF_DESC",data=train,hue = 'CHURN')
# Remove the top and down margin
sns.despine(offset=10, trim=True)
# plotting the violinplot
sns.violinplot(x="CHURN",y="ALL_SEC", hue="CHURN", data=train);

# display the plot
#plt.show()'''
#print("BDD_NAME' : ",train['BDD_NAME'].unique())
#print("TARIFF_DESC : ",train['TARIFF_DESC'].unique())
# create the Labelencoder object
le = preprocessing.LabelEncoder()
#convert the categorical columns into numeric
train['BDD_NAME'] = le.fit_transform(train['BDD_NAME'])
train['TARIFF_DESC'] = le.fit_transform(train['TARIFF_DESC'])
print(type(train))
test['BDD_NAME'] = le.fit_transform(test['BDD_NAME'])
test['TARIFF_DESC'] = le.fit_transform(test['TARIFF_DESC'])

print(train.head(n = 2))
train.fillna(0)
#imp = SimpleImputer(missing_values=np.nan, strategy='mean')

#train = imp.fit_transform(train)  
#train = pd.DataFrame(train)
print(type(train))
print(train.head(n = 2))
#print("SUBSCRIBER_ID : ",len(train['SUBSCRIBER_ID'].unique())) #=114480, each id is unique
# select columns other than 'SUBSCRIBER_ID' and 'CHURN' 
cols = [col for col in train.columns if col not in ['SUBSCRIBER_ID','CHURN']]
#cols_test= [col for col in test.columns if col not in ['SUBSCRIBER_ID','CHURN']]
# dropping the 'Opportunity Number'and 'Opportunity Result' columns
data = train[cols]
#data_test = test[cols_test]
#assigning the Oppurtunity Result column as target
target = train['CHURN']
#split data set into train and test sets
data_train, data_test, target_train, target_test = train_test_split(data,target, test_size = 0.30, random_state = 10)
#create an object of the type GaussianNB
gnb = GaussianNB()
#train the algorithm on training data and predict using the testing data
pred = gnb.fit(data_train, target_train).predict(data_test)
#print(pred.tolist())
#print the accuracy score of the model
print("Naive-Bayes accuracy : ",accuracy_score(target_test, pred, normalize = True))
