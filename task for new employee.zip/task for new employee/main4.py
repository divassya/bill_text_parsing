import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
import warnings

from pre import preprocess 
from plot_data import plot_data

path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"

f = open('metrics.csv', 'w+')
#pred_file = open('predictions.csv', 'w+')
data, target, data_test = preprocess(path)
plot_data(path)
# prepare configuration for cross validation test harness
seed = 7
# prepare models
models = []
models.append(('LR', LogisticRegression(solver="lbfgs", multi_class="auto")))
models.append(('LDA', LinearDiscriminantAnalysis()))
#models.append(('KNN', KNeighborsClassifier()))
models.append(('NB', GaussianNB()))
#models.append(('DT', DecisionTreeClassifier()))
models.append(('RF', RandomForestClassifier(n_estimators=100)))
# evaluate each model in turn
train_results = []
test_results = []
test_results_mean = []
names = []
scoring = ['accuracy', 'average_precision', 'f1']
warnings.simplefilter(action="ignore", category=UserWarning)
for name, model in models:
	kfold = model_selection.KFold(n_splits=10, random_state=seed, shuffle=True)
	cv_results = model_selection.cross_validate(model, data, target, cv=kfold, scoring=scoring, return_train_score=True)
	sorted(cv_results.keys())
	#cv_results = model_selection.cross_val_score(model, data, target, cv=kfold, scoring=scoring)
	train_results.append(cv_results['train_accuracy'])
	test_results.append(cv_results['test_accuracy'])
	test_results_mean.append(cv_results['test_accuracy'].mean())
	names.append(name)
	msg = "%s: Train:%f (+/-%f)" % (name, cv_results['train_accuracy'].mean(), cv_results['train_accuracy'].std())
	msg2 = " Test:%f (+/-%f)\n" % (cv_results['test_accuracy'].mean(), cv_results['test_accuracy'].std())
	f.write("%s: "%(name))
	for item in cv_results:
		f.write("%s: %s\n" %(item, cv_results[item].mean()) )
	print(msg, msg2)
# boxplot algorithm comparison
chosen_model = models[0]
for i in range(len(models)):
	if test_results_mean[i] == max(test_results_mean):
		chosen_model = models[i]
print(chosen_model)
chosen_model[1].fit(data, target)
target_pred = chosen_model[1].predict(data_test)
target_pred = pd.DataFrame(target_pred.T, columns=['CHURN'])
target_pred.to_csv('predictions.csv')

fig = plt.figure()
fig.suptitle('Algorithm Comparison')
ax = fig.add_subplot(111)
plt.boxplot(test_results)
ax.set_xticklabels(names)
#plt.show()
fig.savefig('plots/Alg_comp.png')

f.close()
