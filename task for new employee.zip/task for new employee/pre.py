import pandas as pd
import numpy as np

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

#path = "C:/Users/asus/Documents/8 semester/digital-summer-kcell/task for new employee/task for new employee/"
def preprocess(path):
	train = pd.read_csv(path + "train.csv", sep = ';', encoding = 'cp1251', index_col=0)
	test_real = pd.read_csv(path + "test.csv", sep = ';', encoding = 'cp1251', index_col=0)


	# We create the preprocessing pipelines for both numeric and categorical data.
	categorical_features = list(train.columns[train.dtypes=='object'])
	categorical_transformer = Pipeline(steps=[
		('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
		('onehot', OneHotEncoder(drop='first'))])

		
	numeric_features = [col for col in train.columns if col not in ['SUBSCRIBER_ID','CHURN'] and col not in categorical_features]
	numeric_transformer = Pipeline(steps=[
		('imputer', SimpleImputer(strategy='mean')),
		('scaler', StandardScaler())])

	preprocessor = ColumnTransformer(
		transformers=[
			('num', numeric_transformer, numeric_features),
			('cat', categorical_transformer, categorical_features)])


	# select columns other than 'SUBSCRIBER_ID' and 'CHURN' 
	cols = [col for col in train.columns if col not in ['SUBSCRIBER_ID','CHURN']]
	#cols_test= [col for col in test_real.columns if col not in ['SUBSCRIBER_ID']]
	
	X= train[cols]
	data_test = test_real.loc[:, test_real.columns!='SUBSCRIBER_ID']
	#test_ID = test_real.iloc[:,0]
	#assigning the 'Churn' column as target
	y = train['CHURN']
	

	X = pd.DataFrame(preprocessor.fit_transform(X))
	data_test = pd.DataFrame(preprocessor.fit_transform(data_test))
	return X, y, data_test

	
